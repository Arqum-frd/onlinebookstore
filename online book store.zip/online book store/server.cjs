const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const fs = require('fs'); // optional: to save data in file

const app = express();
const PORT = 5000;

app.use(cors());
app.use(bodyParser.json());

// API to receive form data
app.post('/api/save-user', (req, res) => {
    const userData = req.body;
    console.log("Received data:", userData);

    // Optional: Save to file
    fs.appendFileSync('users.txt', JSON.stringify(userData) + "\n");

    res.status(200).json({ message: "User data saved successfully!" });
});

// Start server
app.listen(PORT, () => {
    console.log(`🚀 Server running on http://localhost:${PORT}`);
});
