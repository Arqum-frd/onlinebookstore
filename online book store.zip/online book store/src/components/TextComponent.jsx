import React from 'react'

export default function TextComponent() {
  return (
    <div className="text">
      <p className='sec1-p'>Turn pages, not heads — but we’ll still make you fall in love. </p><br />
      <h1 className='sec1-h1'>BookStore</h1><br />
      <p className='sec1-p'>Whispers of ink, touches of paper.

        <br />
        Fall hard—into stories, not people.<br />
        for our customers</p>
      Shop books that seduce your soul.</div>
  )
}
