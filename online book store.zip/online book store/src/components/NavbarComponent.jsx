// import React from 'react'
// import { Link } from 'react-router-dom'

// export default function NavbarComponent() {
//   return (
//     <div className="navbar">
//     <div className="nav-logo">
//         <h5>Bean Scene</h5>
//     </div>
//     <div className="nav-links">
//         <ul>
//             <Link to={"/"}>Home</Link>
//             <Link to={"/menu"}>Menu</Link>
//             <Link to={"/about"}>About Us</Link>
//             <Link to={"/services"}>services</Link>
            
//         </ul>
//     </div>
//     <div className="nav-buttons">
//         <button className='signin'>Sign In</button>
//         <button className='signup'>Sign Up</button>
//     </div>
// </div>
// )
// }
import React from 'react';
import { Link } from 'react-router-dom';

export default function NavbarComponent({ onSignInClick, onSignUpClick }) {
  return (
    <div className="navbar">
      <div className="nav-logo">
        {/* <h5>Bean Scene</h5> */}
      </div>
      <div className="nav-links">
        <ul>
          <Link to={"/"}>Home</Link>
          <Link to={"/menu"}>Menu</Link>
          <Link to={"/about"}>About Us</Link>
          <Link to={"/services"}>Services</Link>
        </ul>
      </div>
      <div className="nav-buttons">
        <button className='signin' onClick={onSignInClick}>Sign In</button>
        <button className='signup' onClick={onSignUpClick}>Sign Up</button>
      </div>
    </div>
  );
}
