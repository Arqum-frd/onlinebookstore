// // import React from 'react'
// // import ButtonComponent from './ButtonComponent'
// // import { useNavigate } from 'react-router-dom'

// // export default function CardComponent(props) {
// //     const navigate = useNavigate()
// //     let product = {
// //         title: props.title,
// //         image: props.image,
// //         desc: props.des,
// //         rate: props.rate
// //     }
// //     return (
// //         <div className="card">
// //             <img src={props.image} style={props.imgstlye} />
// //             <h3>{props.title}</h3>
// //             <p>{props.des}</p>
// //             <h5>{props.rate}</h5>
// //             <button onClick={() => { navigate('/details',{state:product}) }} className='sec3-btn'>Order Now</button>
// //             {/* <ButtonComponent/> */}
// //         </div>
// //     )
// // }
// import React from 'react';

// export default function CardComponent({ image, imgstlye, title, des, rate, color }) {
//   return (
//     <div style={{ backgroundColor: color || '#fff', padding: '20px', borderRadius: '10px', margin: '10px', textAlign: 'center' }}>
//       <img src={image} alt={title} style={imgstlye} />
//       <h2>{title}</h2>
//       <p>{des}</p>
//       <p><strong>{rate}</strong></p>
//     </div>
//   );
// }
import React from 'react';

export default function CardComponent({ image, imgstlye, title, des, rate, color, onAddToCart }) {
  return (
    <div className="card" style={{ backgroundColor: color, padding: '15px', borderRadius: '10px' }}>
      <img src={image} alt={title} style={imgstlye} />
      <h3>{title}</h3>
      <p>{des}</p>
      <p><strong>{rate}</strong></p>
      {/* <button onClick={onAddToCart} className="add-to-cart-btn">Add to Cart</button> */}
    </div>
  );
}


