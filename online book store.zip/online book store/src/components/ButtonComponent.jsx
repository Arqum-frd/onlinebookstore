// import React from 'react'

// export default function ButtonComponent(props) {
//   return (
//     <button className='btn'>Order Now</button>
//   )
// }
import React from 'react';
import { useNavigate } from 'react-router-dom';

export default function ButtonComponent() {
  const navigate = useNavigate();

  const goToMenu = () => {
    navigate('/menu'); // This will navigate to Menu page
  };

  return (
    <button className='btn' onClick={goToMenu}>Order Now</button>
  );
}
