import React from 'react'
import { createBrowserRouter, RouterProvider } from 'react-router-dom'
import Home from './pages/Home'
import About from './pages/About'
import Menu from './pages/Menu'
import Services from './pages/Services'
import ProductDetails from './pages/ProductDetails'
import signin from "./pages/signin";


export default function App() {

    const router = createBrowserRouter([
        {
            path: "/",
            element: <Home />
        },
        {
            path: "/about",
            element: <About />
        },
        {
            path: "/Menu",
            element: <Menu />
        },
        {
            path: "/services",
            element: <Services />
        },
         {
            path: "/details",
            element: <ProductDetails />
        }
    ])
    return (
        <>

            <RouterProvider router={router} />
        </>
    )
    
}
