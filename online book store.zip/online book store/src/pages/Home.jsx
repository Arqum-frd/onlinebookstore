// import React from 'react'
// import '../App.css'
// import NavbarComponent from '../components/NavbarComponent'
// import TextComponent from '../components/TextComponent'
// import ButtonComponent from '../components/ButtonComponent'
// import CardComponent from '../components/CardComponent'

// export default function Home() {
//     return (
//         <>
//             <div className="section1">
//                 <NavbarComponent />
//                 <TextComponent />
//                 <ButtonComponent />
//             </div>
            
           
//         </>
//     )
// }
import React, { useState } from 'react';
import '../App.css';
import NavbarComponent from '../components/NavbarComponent';
import TextComponent from '../components/TextComponent';
import ButtonComponent from '../components/ButtonComponent';
import CardComponent from '../components/CardComponent';

export default function Home() {
  const [formType, setFormType] = useState(""); // "signin" or "signup"
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    address: "",
    password: ""
  });

  const handleChange = (e) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  const handleSubmit = async (e) => {
  e.preventDefault();

  try {
    const res = await fetch('http://localhost:5000/api/save-user', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(formData)
    });

    if (res.ok) {
      alert(`${formType === "signin" ? "Signed in" : "Signed up"} as ${formData.name}`);
      setFormType("");
      setFormData({ name: "", email: "", address: "", password: "" });
    } else {
      alert("Failed to submit.");
    }
  } catch (error) {
    console.error("Error:", error);
    alert("Server error");
  }
};


  return (
    <>
    <div className="home">
      <div className="section1">
        <NavbarComponent onSignInClick={() => setFormType("signin")} onSignUpClick={() => setFormType("signup")} />
        <TextComponent />
        <ButtonComponent />
        {/* <CardComponent /> */}
      </div>

      {/* Popup form */}
      {formType && (
        <div style={modalStyle}>
          <div style={formBoxStyle}>
            <h2>{formType === "signin" ? "Sign In" : "Sign Up"}</h2>
            <form onSubmit={handleSubmit}>
              <input type="text" name="name" placeholder="Full Name" value={formData.name} onChange={handleChange} required /><br /><br />
              <input type="email" name="email" placeholder="Email" value={formData.email} onChange={handleChange} required /><br /><br />
              <input type="text" name="address" placeholder="Address" value={formData.address} onChange={handleChange} required /><br /><br />
              <input type="password" name="password" placeholder="Password" value={formData.password} onChange={handleChange} required /><br /><br />
              <button type="submit">{formType === "signin" ? "Login" : "Register"}</button>
              <button type="button" onClick={() => setFormType("")} style={{ marginLeft: "10px" }}>Cancel</button>
            </form>
          </div>
        </div>
        
      )}
      </div>
    </>
  );
}

const modalStyle = {
  position: 'fixed',
  top: 0,
  left: 0,
  width: '100vw',
  height: '100vh',
  background: 'rgba(0,0,0,0.5)',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  zIndex: 999
};

const formBoxStyle = {
  background: '#fff',
  padding: '25px',
  borderRadius: '10px',
  width: '350px',
  boxShadow: '0 0 15px rgba(0,0,0,0.3)',
  textAlign: 'center'
};
