import React from "react";
import NavbarComponent from '../components/NavbarComponent';
import CardComponent from '../components/CardComponent';


import "../App.css";

export default function Home() {
  const books = [
    {
      title: "The Silent Patient",
      desc: "A twisty psychological thriller.",
      price: "$12.99",
      img: "src/assets/The Silent Patient.jpg"
    },
    {
      title: "Atomic Habits",
      desc: "Build good habits, break bad ones.",
      price: "11.50",
      img: "src/assets/Atomic Habit.jpeg"
    },
    {
      title: "Verity",
      desc: "Dark, romantic suspense.",
      price: "$13.75",
      img: "src/assets/Verity.jpg"
    },
    {
      title: "The Midnight Library",
      desc: "Live all your regrets.",
      price: "$10.00",
      img: "src/assets/The Midnight Library.jpeg"
    },
    {
      title: "It Ends with Us",
      desc: "Love, pain, and choices.",
      price: "$12.25",
      img: "src/assets/It Ends with Us.avif"
    },
    {
      title: "Rich Dad Poor Dad",
      desc: "Guide to financial freedom.",
      price: "$9.99",
      img: "src/assets/Rich Dad Poor Dad.jpeg"
    },
    {
      title: "The Subtle Art of Not Giving a F*ck",
      desc: "Unfiltered life advice.",
      price: "$13.99",
      img: "src/assets/the-subtle-art-of-not-giving-a-fck-cover@8x.png"
    },
    {
      title: "The Alchemist",
      desc: "Fulfill your destiny.",
      price: "$10.25",
      img: "src/assets/The Alchemist.jpeg"
    },
    {
      title: "Think and Grow Rich",
      desc: "Success principles.",
      price: "$8.99",
      img: "src/assets/Think and Grow Rich.jpeg"
    },
    {
      title: "Ugly Love",
      desc: "A heartbreaking romance.",
      price: "$11.49",
      img: "src/assets/Ugly Love.jpeg"
    },
    {
      title: "Eleanor Oliphant",
      desc: "Quirky and heartwarming.",
      price: "$9.75",
      img: "src/assets/Eleanor Oliphant.jpeg"
    },
    {
      title: "Reminders of Him",
      desc: "Grief and love.",
      price: "$12.95",
      img: "src/assets/Reminders of Him.jpg"
    }
  ];

  return (
    <><NavbarComponent /><div className="sec-2" style={{ padding: "30px" }}>
      <h2 style={{ textAlign: "center", marginBottom: "20px" }}>
        📚 Featured Books
      </h2>
      <div
        className="book-grid"
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))",
          gap: "20px"
        }}
      >
        {books.map((book, index) => (
          <div
            key={index}
            style={{
              border: "1px solid #ccc",
              padding: "15px",
              borderRadius: "8px",
              backgroundColor: "#fff",
              boxShadow: "0 2px 8px rgba(0,0,0,0.05)",
              textAlign: "center"
            }}
          >
            <img
              src={book.img}
              alt={book.title}
              style={{
                width: "200px",
                height: "300px",
                objectFit: "cover",
                borderRadius: "4px"
              }} />
            <h4 style={{ marginTop: "10px" }}>{book.title}</h4>
            <p>{book.desc}</p>
            <strong>{book.price}</strong>
          </div>
        ))}
      </div>
    </div></>
  );
}
