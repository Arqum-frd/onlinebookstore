// import React, { useState } from 'react';
import React from 'react'
// import React, { useState, useEffect, useRef } from 'react';

export default function Checkout({ cartItems }) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    address: ''
  });

  const handleChange = (e) => {
    setFormData({...formData, [e.target.name]: e.target.value});
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const orderData = {
      customer: formData,
      cart: cartItems
    };

    try {
      const res = await fetch('http://localhost/checkout.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(orderData)
      });

      if (res.ok) {
        alert('✅ Order placed successfully!');
      } else {
        alert('❌ Order failed.');
      }
    } catch (err) {
      alert('⚠️ Server error');
    }
  };

  return (
    <div className="checkout">
      <h2>Checkout</h2>
      <form onSubmit={handleSubmit}>
        <input name="name" placeholder="Full Name" onChange={handleChange} required />
        <input name="email" type="email" placeholder="Email" onChange={handleChange} required />
        <textarea name="address" placeholder="Address" onChange={handleChange} required />
        <button type="submit">Place Order</button>
      </form>

      <h3>Items in Cart:</h3>
      <ul>
        {cartItems.map(item => (
          <li key={item._id}>{item.title} - ${item.price}</li>
        ))}
      </ul>
    </div>
  );
}
