import React from 'react'
import NavbarComponent from '../components/NavbarComponent'

export default function About() {
  return (
    <div>
        <NavbarComponent/>
         <div className="section2">
                <div className="text">
                    <h1 className='sec2-h1'>Hot Selling Book of the Year: Atomic Habits by James Clear</h1>
                    <p className='sec2-p'>
                        Backed by science and real-life stories, it shows how small changes lead to remarkable results.
James Clear explains how to reshape your identity through tiny, consistent actions.
Perfect for anyone seeking personal growth, focus, or lasting success.
This bestselling book is your roadmap to lifelong positive change.

</p>
                </div>
                <div className="sec2-img">
                    <img src="src/assets/bookpic.jpeg" width="200px" alt="" />
                </div>
            </div> 
    </div>
  )
}
