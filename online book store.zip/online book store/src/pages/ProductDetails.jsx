import React from 'react'
import { useLocation } from 'react-router-dom'

export default function ProductDetails() {

    const location = useLocation()
    console.log(location.state)

    const {image,title,des,rate}= location.state
  return (
    <div>
        <img src={image} alt="" />
        <p>{des}</p>
        <h1>{title}</h1>
        <h6>{rate}</h6>
    </div>
  )
}
